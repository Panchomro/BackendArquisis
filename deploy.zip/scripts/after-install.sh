echo "Pulling aplication"
docker-compose --file /home/ubuntu/docker-compose.production.yml pull