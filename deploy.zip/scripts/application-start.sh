echo "Starting application..."
docker-compose --file /home/ubuntu/docker-compose.production.yml up -d