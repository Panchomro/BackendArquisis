echo "Stop aplication"
# docker-compose --file docker-compose.production.yml down