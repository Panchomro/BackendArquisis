echo "Stop aplication"
docker-compose --file home/ubuntu/docker-compose.production.yml down